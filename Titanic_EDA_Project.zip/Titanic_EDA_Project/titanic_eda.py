# Titanic Dataset EDA Script
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Import Libraries
df = pd.read_csv('train.csv')

# 2. Display the first few rows of the dataset
print("Dataset Info:")
print(df.info())

print("\nDataset Description:")
print(df.describe())

print("\nMissing Values:")
print(df.isnull().sum())

# 3. Display the first few rows of the dataset
print("\nSurvived value counts:")
print(df['Survived'].value_counts())

print("\nPclass value counts:")
print(df['Pclass'].value_counts())

print("\nSex value counts:")
print(df['Sex'].value_counts())

# 4. Visualizations

sns.pairplot(df[['Survived', 'Pclass', 'Age', 'Fare']])
plt.show()

# 5. Barplot (Survived vs Pclass)
plt.figure(figsize=(10,6))
sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
plt.title("Correlation Heatmap")
plt.show()

# 6. Barplot (Survived vs Pclass)
plt.figure(figsize=(8,5))
sns.histplot(df['Age'].dropna(), bins=30, kde=True)
plt.title("Distribution of Age")
plt.show()

# 7. Barplot (Survived vs Pclass)
plt.figure(figsize=(8,5))
sns.boxplot(x='Survived', y='Age', data=df)
plt.title("Survival vs Age")
plt.show()

# 8. Barplot (Survived vs Pclass)
plt.figure(figsize=(8,5))
sns.countplot(x='Survived', hue='Sex', data=df)
plt.title("Survival Count by Gender")
plt.show()

# 9. Barplot (Survived vs Pclass)
plt.figure(figsize=(8,5))
sns.scatterplot(x='Age', y='Fare', hue='Survived', data=df)
plt.title("Fare vs Age (Survival status)")
plt.show()

# 11. Observations (You will write your findings below each graph in your report)

# 12. Summary (to be written as final PDF report)
